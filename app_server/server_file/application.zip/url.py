#일반 공지 페이지
general = 'https://wise.dongguk.ac.kr/article/generalnotice/'

acd = 'https://wise.dongguk.ac.kr/article/acdnotice/'

empprg = 'https://wise.dongguk.ac.kr/article/empprg/'


#일반 공지 페이지
general = 'https://wise.dongguk.ac.kr/article/generalnotice/list#none'

acd = 'https://wise.dongguk.ac.kr/article/acdnotice/list'

empprg = 'https://wise.dongguk.ac.kr/article/empprg/list'


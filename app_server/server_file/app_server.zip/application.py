from flask import Flask, jsonify
import crawling
import time as t
import url

class timeset:
    pass

start_time = t.time()
general_noti = crawling.noti_page_parser(url.general)
acd_noti = crawling.noti_page_parser(url.acd)
empprg_noti = crawling.noti_page_parser(url.empprg)
application = Flask(__name__)

@application.route('/')
def Check_connection():
    return '1'

@application.route('/num')
def num():
    return '10'

@application.route('/information/generalnotice')
def generalnotice_information():
    global start_time, general_noti
    now_time = t.time() - start_time
    print(now_time)

    if(now_time > 3600):
        start_time = t.time()
        print("공지 새로 고침")
        general_noti = crawling.noti_page_parser(url.general)

    return jsonify(general_noti)

@application.route('/information/acdnotice')
def acdnotice_information():
    global start_time, acd_noti
    now_time = t.time() - start_time
    print(now_time)

    if(now_time > 3600):
        start_time = t.time()
        print("공지 새로 고침")
        acd_noti = crawling.noti_page_parser(url.acd)

    return jsonify(acd_noti)

@application.route('/information/empprgnoti')
def empprgnoti_information():
    global start_time, empprg_noti
    now_time = t.time() - start_time
    print(now_time)

    if(now_time > 3600):
        start_time = t.time()
        print("공지 새로 고침")
        empprg_noti = crawling.noti_page_parser(url.empprg)

    return jsonify(empprg_noti)

if __name__ == '__main__':
    application.run()